Author: CodexWorld
Author URL: http://www.codexworld.com/
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/create-manage-html-pages-dynamically-with-php-mysql/

============ Instructions ============
1. In the "config.php" file, specify the database host (DB_HOST), username (DB_USERNAME), password (DB_PASSWORD), and name (DB_NAME) as per the MySQL database credentials.

2. Open the "index.php" file on the browser ===> Test the HTML web page management function.



============ May I Help You ===========
Do reach out to us at support@codexworld.com if you have any trouble implementing this or if you need any help.

If you have any queries about this script, send the query by posting a comment here - http://www.codexworld.com/create-manage-html-pages-dynamically-with-php-mysql/#respond